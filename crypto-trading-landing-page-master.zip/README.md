# crypto-trading-landing-page
This is a landing page for a cryptocurrency trading platform. It features a header with a navigation bar, a hero section with a title and a subtitle, a body section with a button, and a footer with a coin list.
### script.js
The function to get the current price of Bitcoin,ethereum,dogecoin uses the <b> jQuery library </b>to make an AJAX request to the <b>CoinGecko API</b>. The response from the API is then used to update the price of Bitcoin in the browser.
## preview <a href="https://poorani-27.github.io/crypto-trading-landing-page/">link</a>
